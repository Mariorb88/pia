from sklearn.base import BaseEstimator, TransformerMixin
import numpy as np

class AgeOutlierImputer(BaseEstimator, TransformerMixin):
    """
    Custom transformer to handle age outliers by imputing values over 150 
    with the median age of the dataset.
    """
    def __init__(self, threshold=150):
        self.threshold = threshold
        self.median_age = None
        
    def fit(self, X, y=None):
        # Calculate median age excluding outliers
        self.median_age = np.median(X[X <= self.threshold])
        return self
        
    def transform(self, X):
        X_copy = X.copy()
        mask = X_copy > self.threshold
        X_copy[mask] = self.median_age
        return X_copy
    
class TSHLogTransformer(BaseEstimator, TransformerMixin):
    """
    Custom transformer to handle TSH's right-skewed distribution 
    using log transformation with handling of zeros.
    """
    def fit(self, X, y=None):
        return self
        
    def transform(self, X):
        X_copy = X.copy()
        # Add small constant before log transform to handle zeros
        return np.log1p(X_copy)
    
    
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.impute import SimpleImputer


standard_numeric = ['TT4', 'T4U', 'FTI', 'T3']

# Special handling for TSH (right-skewed distribution)
tsh_feature = ['TSH']


# Binary categorical features
binary_features = ['on_thyroxine', 'query_on_thyroxine', 'on_antithyroid_meds',
                    'sick', 'pregnant', 'thyroid_surgery', 'I131_treatment',
                    'query_hypothyroid', 'query_hyperthyroid', 'lithium',
                    'goitre', 'tumor', 'hypopituitary', 'psych']

# categorical categorical features
categorical_features = ['sex', 'referral_source']

# Create specialized pipelines
age_pipeline = Pipeline([
    ('outlier_handler', AgeOutlierImputer(threshold=150)),
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

standard_numeric_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

tsh_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('log_transform', TSHLogTransformer()),
    ('scaler', StandardScaler())
])

categorical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False)),
])



def get_preprocessing_pipeline():
    """
    Devuelve un pipeline de preprocesamiento 
    """
    
    return ColumnTransformer(
    transformers=[
        ('age', age_pipeline, ['age']),
        ('standard_numeric', standard_numeric_pipeline, standard_numeric),
        ('tsh', tsh_pipeline, tsh_feature),
        ('binary', OneHotEncoder(drop='if_binary', handle_unknown='ignore', sparse_output=False), 
            binary_features),
        ('categorical', categorical_pipeline, categorical_features),
    ],
    remainder='drop'
)


def scale_target(y_train, y_val, y_test):
    """
    Scale target variables using StandardScaler.
    
    Args:
        y_train: Training target values
        y_val: Validation target values  
        y_test: Test target values
        
    Returns:
        tuple: (scaled training data, scaled validation data, scaled test data, scaler)
    """
    y_scaler = StandardScaler()
    y_train_scaled_np = y_scaler.fit_transform(y_train.values.reshape(-1, 1))
    y_val_scaled_np = y_scaler.transform(y_val.values.reshape(-1, 1))
    y_test_scaled_np = y_scaler.transform(y_test.values.reshape(-1, 1))
    
    return y_train_scaled_np, y_val_scaled_np, y_test_scaled_np, y_scaler